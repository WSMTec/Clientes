<!--<div style="display: flex;
     justify-content: center;
     align-items: center;
     background-color: #212c55;">
    <a style="margin: 10px 10px;" href="https://www.facebook.com/albertopretoadvocacia" target="_blank"><img src="https://www.albertopreto.adv.br/themes/alberto/images/footer/facebook.png"></a>
    <a style="margin: 10px 10px;" href="https://www.instagram.com/alberto_preto/" target="_blank"><img src="https://www.albertopreto.adv.br/themes/alberto/images/footer/instagram.png"></a>
    <a style="margin: 10px 10px;" href="https://twitter.com/alberto_preto" target="_blank"><img src="https://www.albertopreto.adv.br/themes/alberto/images/footer/twitter.png"></a>
    <a style="margin: 10px 10px;" href="https://www.linkedin.com/in/alberto-preto-ab448b10b?trk=hp-identity-name" target="_blank"><img src="https://www.albertopreto.adv.br/themes/alberto/images/footer/linkedin.png"></a>
    <a style="margin: 10px 10px;" href="https://wa.me/5511947529989" target="_blank"><img src="https://www.albertopreto.adv.br/themes/alberto/images/footer/whatsapp.png"></a>
    <a style="margin: 10px 10px;" href="https://www.youtube.com/channel/UC90NnFnu9UabqsxQepyqwRg?view_as=subscriber" target="_blank"><img src="https://www.albertopreto.adv.br/themes/alberto/images/footer/youtube.png"></a>
</div>-->