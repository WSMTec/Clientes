<!--HOME CONTENT-->
<div class="content">
    <article style="padding: 6em; text-align: center;" class="page_notfound">

        <div style="font-size: 2em;" class="notfounerror">404</div>

        <header class="cat_header">
            <h1>Opsss. Não encontrado!</h1>
            <p class="tagline">Desculpe, o conteúdo que você procura não existe ou foi movido daqui.</p>
        </header>
    </article>

    <div class="clear"></div>
</div><!--/ site container -->