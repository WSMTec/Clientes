<section class="section_escritorio">

    <header class="section_escritorio_header">
        <div class="content">
            <h1>Quem somos</h1>
            <div class="quem_s">
                <p>
                    Natural de São Paulo/SP e formado em 1970 na Faculdade de Direito da Universidade Mackenzie de São Paulo.
                    Membro da então Comissão Especial de Reforma da Lei de Falências da OAB/SP para a atual Lei.
                </p>
<!--                <br/>
                <p>
                    
                </p>-->
            </div>
        </div>
    </header>
    <div class="section_escritorio_div content">
        <!--<div class="content">-->
        <article class="section_escritorio_article">
            <h2>
                MISSÃO
            </h2>
            <p>
                Atender nossos clientes com excelência
            </p>
        </article>
        <article class="section_escritorio_article">
            <h2>
                VISÃO
            </h2>
            <p>
                Estamos sempre em expansão de conhecimento, atentos as Leis atuais e as novas Leis para que nossos clientes estejam amparados diante as regras atuais e as novas regras.
        </article>
        <article class="section_escritorio_article">
            <h2>
                VALORES
            </h2>
            <p>
                Procuramos atender nossos clientes com o mais alto padrão
        </article>
        <!--</div>-->
    </div>
</section>

