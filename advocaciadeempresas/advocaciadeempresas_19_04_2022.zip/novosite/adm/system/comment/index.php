<main class="content">
    <header class="header-box">
        <h2 class="header-box-h">Gerencie os comentários dos posts</h2>
        <div class="header-box-btn">
            <!--<a class="btn-default btn-blue" href="?exe=comment/create"><span class="lnr lnr-plus-circle"></span> Nova categoria</a>-->
        </div>
    </header>

    <div class="box">
        <table id="table-comment" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th><span class="lnr lnr-layers"></span> Visitor</th>
                    <th><span class="lnr lnr-text-align-left"></span> Comentário</th>
                    <th><span class="lnr lnr-text-align-left"></span> Status</th>
                    <th></th>
                </tr>
            </thead>

            <tfoot>
                <tr>
                    <th><span class="lnr lnr-layers"></span> Visitor</th>
                    <th><span class="lnr lnr-text-align-left"></span> Comentário</th>
                    <th><span class="lnr lnr-text-align-left"></span> Status</th>
                    <th></th> 
                </tr>
            </tfoot>
        </table>
    </div>
</main>