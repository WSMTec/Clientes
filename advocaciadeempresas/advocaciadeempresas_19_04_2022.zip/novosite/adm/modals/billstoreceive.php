<?php
$data = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
?>
<div class="app_modal" data-modalclose="true">
    <div class="app_modal_box app_modal_views ctrec" data-class="ctrec">
        <p class="title icon-calendar-minus-o">Visualizar conta a receber:</p>
        <div class="box_views">

        </div>
    </div>
</div>

<!---->
<!--<div class="app_modal_box app_modal_ipi">-->
<!--    <p class="title icon-calendar-minus-o">Selecione o IPI:</p>-->
<!--    <div class="app_modal_box_form">-->
<!--        <form class="form_modal" method="post" action="../source/App/Search.php">-->
<!--            <input type="hidden" name="action" value="ipi"/>-->
<!--            <input placeholder="Buscar código ou descrição" type="text" name="buscar">-->
<!--            <button class="btn-default btn-green" type="submit">Buscar</button>-->
<!--        </form>-->
<!--    </div>-->
<!--    <div class="app_modal_box_select">-->
<!--        <table class="table-default" width="100%">-->
<!--            <thead class="th-default">-->
<!--            <tr>-->
<!--                <th>Codigo</th>-->
<!--                <th>Descrição</th>-->
<!--            </tr>-->
<!--            </thead>-->
<!--            <tbody class="tbody_select_ipi">-->
<!---->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->
<!--</div>-->
<!---->
<!--<div class="app_modal_box app_modal_pis">-->
<!--    <p class="title icon-calendar-minus-o">Selecione o PIS:</p>-->
<!--    <div class="app_modal_box_form">-->
<!--        <form class="form_modal" method="post" action="../source/App/Search.php">-->
<!--            <input type="hidden" name="action" value="pis"/>-->
<!--            <input placeholder="Buscar código ou descrição" type="text" name="buscar">-->
<!--            <button class="btn-default btn-green" type="submit">Buscar</button>-->
<!--        </form>-->
<!--    </div>-->
<!--    <div class="app_modal_box_select">-->
<!--        <table class="table-default" width="100%">-->
<!--            <thead class="th-default">-->
<!--            <tr>-->
<!--                <th>Codigo</th>-->
<!--                <th>Descrição</th>-->
<!--            </tr>-->
<!--            </thead>-->
<!--            <tbody class="tbody_select_pis">-->
<!---->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->
<!--</div>-->